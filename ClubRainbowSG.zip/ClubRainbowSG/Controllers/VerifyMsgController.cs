﻿using Microsoft.AspNetCore.Mvc;

namespace clubrainbow.Controllers
{
    public class VerifyMsgController : Controller
    {
        public IActionResult Msg()
        {
            return View();
        }
    }
}
