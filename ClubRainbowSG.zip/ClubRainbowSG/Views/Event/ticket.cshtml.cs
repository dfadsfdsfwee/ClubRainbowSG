using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClubRainbowSG.Views.Event
{
    public class ticketModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
