using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClubRainbowSG.Views.Event
{
    public class myeventModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
