using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClubRainbowSG.Views.Event
{
    public class canceleventModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
