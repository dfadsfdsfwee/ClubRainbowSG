using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClubRainbowSG.Views.Home
{
    public class RegistrationDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
