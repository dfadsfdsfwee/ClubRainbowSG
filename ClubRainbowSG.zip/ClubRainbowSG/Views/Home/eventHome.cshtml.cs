using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ClubRainbowSG.Views.Home
{
    public class eventHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
