using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace clubrainbow.Views.Password
{
    public class passwordchangedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
