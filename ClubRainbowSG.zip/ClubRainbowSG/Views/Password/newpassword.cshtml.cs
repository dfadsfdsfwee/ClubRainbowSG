using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace clubrainbow.Views.Password
{
    public class newpasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
