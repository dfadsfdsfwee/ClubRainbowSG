using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace clubrainbow.Views.Password
{
    public class ReserPasswordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
